
var archive = require('../helpers/archive-helpers');
archive.readListOfUrls(archive.downloadUrls);
