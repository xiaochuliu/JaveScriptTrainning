import React from 'react';

const Spinner = (props) => {
  return (
    <div className="spinner">
      <img src="images/spiffygif_46x46.gif" />
    </div>
  );
};

export default Spinner;
